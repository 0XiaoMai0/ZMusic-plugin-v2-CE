<div align="center">

![][banner]

![][tested-versions]
![][players]
![][servers]

![][releases]
![][downloads]
![][license]

[文档][docs-link] | [QQ 群1032722724]

</div>

## 简介

## ZMusic CE

ZMusic CE 是基于 ZMusic V2 分支修复和整理的音乐点歌插件版本，主要用于 Minecraft Java 服务端，让玩家可以在游戏内搜索、点歌、播放音乐，并通过 ZMusic 客户端 Mod 接收播放。

本版本主要面向 Purpur / Paper / Spigot 系服务端使用，适合需要在服务器内提供点歌、歌词显示、音乐播放功能的服主。

---

## 主要功能

- 支持游戏内点歌与播放音乐
- 支持网易云音乐相关登录与播放修复
- 支持歌词显示
- 支持玩家自助点歌
- 支持服务端向安装 ZMusic Mod 的客户端发送播放数据
- 修复部分情况下播放失败、登录状态异常、Cookie 处理异常等问题

---

## 安装方法

1. 将插件 jar 放入服务端的 `plugins` 文件夹
2. 启动服务器生成配置文件
3. 停止服务器
4. 修改 `plugins/ZMusic/config.json`
5. 重新启动服务器
6. 客户端需要安装对应版本的 ZMusic Mod，否则无法正常听歌

---

## 重要注意事项

### 使用前请务必关闭自动更新

请打开 `plugins/ZMusic/config.json`，将自动更新检查关闭：

```json
"check-update": false

如果不关闭，服务器可能会在启动时访问作者原接口检查更新。部分服务器网络无法连接该接口时，会在控制台出现类似 Connect timed out 的报错。
该报错一般不影响插件主体功能，但会影响观感，因此建议关闭。

## 文档



## 仓库

* [ZMusic](https://github.com/RealHeart/ZMusic) - 插件
* [ZMusic Mod](https://github.com/RealHeart/ZMusic-Mod) - 配套模组
* [ZMusic Docs](https://github.com/RealHeart/ZMusic-Docs) - 使用文档

## 开源协议

本项目使用 [GPL-3.0](LICENSE) 协议开放源代码

```text
ZMusic - Powerful Music System
Copyright (C) 2024 ZhenXin
This program is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.
This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.
You should have received a copy of the GNU General Public License
along with this program.  If not, see <http://www.gnu.org/licenses/>.
```

## 贡献者

[![][contrib]](https://github.com/RealHeart/ZMusic/graphs/contributors)

[banner]: https://socialify.git.ci/RealHeart/ZMusic/image?description=1&forks=1&issues=1&language=1&name=1&owner=1&pulls=1&stargazers=1&theme=Auto

[license]: https://img.shields.io/github/license/RealHeart/ZMusic?style=for-the-badge

[players]: https://img.shields.io/bstats/players/7291?label=players&style=for-the-badge

[servers]: https://img.shields.io/bstats/servers/7291?label=servers&style=for-the-badge

[tested-versions]: https://img.shields.io/spiget/tested-versions/83027?style=for-the-badge

[releases]: https://img.shields.io/github/v/release/RealHeart/ZMusic?style=for-the-badge

[downloads]: https://img.shields.io/github/downloads/RealHeart/ZMusic/total?style=for-the-badge

[contrib]: https://contrib.rocks/image?repo=RealHeart/ZMusic

[docs-link]: https://zmusic.zhenxin.me

[qq-group-link]: https://jq.qq.com/?_wv=1027&k=9Xs1RMt5

[discord-link]: https://discord.gg/twQgJNufYn